// app/src/main/java/com/example/licenta/data/Reading.kt
package com.example.licenta.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "readings")
data class Reading(
    @PrimaryKey val timestamp: Long,
    val bpm: Int,
    val spo2: Int
)
