// app/src/main/java/com/example/licenta/MainViewModel.kt
package com.example.licenta

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.licenta.data.AppDatabase
import com.example.licenta.data.Reading
import com.example.licenta.data.ReadingRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = ReadingRepository(
        AppDatabase.getInstance(app).readingDao()
    )

    val readings = repo.readings
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    fun addReading(r: Reading) {
        viewModelScope.launch {
            repo.insert(r)
        }
    }
}
