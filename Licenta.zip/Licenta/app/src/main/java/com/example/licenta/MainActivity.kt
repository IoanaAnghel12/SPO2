// app/src/main/java/com/example/licenta/MainActivity.kt
package com.example.licenta

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.annotation.RequiresPermission
import androidx.core.app.ActivityCompat
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.licenta.data.Reading
import com.example.licenta.ui.theme.LicentaTheme
import java.util.*

class MainActivity : ComponentActivity() {
    companion object {
        private val SERVICE_UUID            = UUID.fromString("12345678-1234-1234-1234-1234567890ab")
        private val CHARACTERISTIC_UUID     = UUID.fromString("abcd1234-5678-5678-5678-abcdefabcdef")
        private val CLIENT_CHAR_CONFIG_UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
        private const val DEVICE_NAME       = "ESP32-Puls"
        private const val TAG               = "LICENTA_BLE"
    }

    private var bluetoothAdapter: BluetoothAdapter? = null
    private var bluetoothGatt:    BluetoothGatt?    = null
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestPermissions()
        bluetoothAdapter = (getSystemService(BLUETOOTH_SERVICE) as
                android.bluetooth.BluetoothManager).adapter
        startBleScan()

        setContent {
            LicentaTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color    = MaterialTheme.colorScheme.background
                ) {
                    val readings = viewModel.readings.collectAsState().value
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        readings.firstOrNull()?.let { r ->
                            Text("Puls: ${r.bpm} BPM",
                                style = MaterialTheme.typography.headlineMedium)
                            Spacer(Modifier.height(8.dp))
                            Text("SpO₂: ${r.spo2} %",
                                style = MaterialTheme.typography.headlineMedium)
                            Spacer(Modifier.height(16.dp))
                        }
                        LazyColumn {
                            items(readings) { r ->
                                Text("${Date(r.timestamp)} → ${r.bpm} BPM, ${r.spo2}%")
                                Spacer(Modifier.height(4.dp))
                            }
                        }
                    }
                }
            }
        }
    }

    private fun requestPermissions() {
        val perms = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            perms += Manifest.permission.BLUETOOTH_SCAN
            perms += Manifest.permission.BLUETOOTH_CONNECT
        } else {
            perms += Manifest.permission.BLUETOOTH
            perms += Manifest.permission.BLUETOOTH_ADMIN
        }
        ActivityCompat.requestPermissions(this, perms.toTypedArray(), 1001)
    }

    @SuppressLint("MissingPermission")
    private fun startBleScan() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            ActivityCompat.checkSelfPermission(this,
                Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) return

        bluetoothAdapter?.bluetoothLeScanner
            ?.startScan(scanCallback)
        Log.d(TAG, "Scanare BLE pornită…")
    }

    @SuppressLint("MissingPermission")
    private fun connectToDevice(device: BluetoothDevice) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            ActivityCompat.checkSelfPermission(this,
                Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) return

        bluetoothGatt = device.connectGatt(this, false, gattCallback)
        Log.d(TAG, "Se conectează la GATT…")
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val device = result.device
            if (device.name == DEVICE_NAME) {
                bluetoothAdapter
                    ?.bluetoothLeScanner
                    ?.stopScan(this)
                connectToDevice(device)
            }
        }
    }

    @SuppressLint("MissingPermission")
    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(
            gatt: BluetoothGatt, status: Int, newState: Int
        ) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                gatt.discoverServices()
            }
        }

        @SuppressLint("MissingPermission")
        override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
            val service        = gatt.getService(SERVICE_UUID)      ?: return
            val characteristic = service.getCharacteristic(CHARACTERISTIC_UUID) ?: return

            gatt.setCharacteristicNotification(characteristic, true)
            val desc = characteristic.getDescriptor(CLIENT_CHAR_CONFIG_UUID) ?: return
            desc.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            gatt.writeDescriptor(desc)
        }

        override fun onCharacteristicChanged(
            gatt: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic
        ) {
            val raw   = characteristic.getStringValue(0)         // "timestamp,bpm,spo2"
            val parts = raw.split(",")
            if (parts.size >= 3) {
                val ts   = parts[0].toLongOrNull() ?: return
                val bpm  = parts[1].toIntOrNull()    ?: return
                val spo2 = parts[2].toIntOrNull()    ?: return
                viewModel.addReading(Reading(ts, bpm, spo2))
            }
        }
    }

    @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
    override fun onDestroy() {
        super.onDestroy()
        bluetoothGatt?.close()
        bluetoothGatt = null
    }
}
