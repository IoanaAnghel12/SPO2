// app/src/main/java/com/example/licenta/data/ReadingRepository.kt
package com.example.licenta.data

class ReadingRepository(private val dao: ReadingDao) {
    val readings = dao.allReadings()
    suspend fun insert(reading: Reading) = dao.insert(reading)
}
